import { saveStory, getAllStories } from './indexedDB.js';

function transformStory(apiStory) {
  return {
    id: apiStory.id,
    title: apiStory.title || 'Tanpa Judul',
    description: apiStory.description || '',
    photoUrl: apiStory.photoUrl || '',
    lat: apiStory.lat || null,
    lon: apiStory.lon || null,
    createdAt: apiStory.createdAt || new Date().toISOString(),
  };
}

export async function fetchStoriesWithCache() {
  try {
    const res = await fetch('/api/stories');
    if (!res.ok) throw new Error('Fetch gagal');
    const { listStory } = await res.json();

    for (const apiStory of listStory) {
      const story = transformStory(apiStory);
      await saveStory(story);
    }
    return listStory;
  } catch {
    return await getAllStories();
  }
}
