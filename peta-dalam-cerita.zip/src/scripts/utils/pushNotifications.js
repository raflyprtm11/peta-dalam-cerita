import storyApi from '../api/storyApi.js';

const VAPID_PUBLIC_KEY = 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk';

export function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = atob(base64);
    return Uint8Array.from([...rawData].map(c => c.charCodeAt(0)));
}

export function arrayBufferToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    bytes.forEach(b => binary += String.fromCharCode(b));
    return btoa(binary);
}

export async function enablePushNotifications() {
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
        throw new Error('Permission not granted');
    }

    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
    });

    const rawP256dh = subscription.getKey('p256dh');
    const rawAuth = subscription.getKey('auth');
    const p256dh = arrayBufferToBase64(rawP256dh);
    const auth = arrayBufferToBase64(rawAuth);
    const endpoint = subscription.endpoint;

    return storyApi.subscribePush({ endpoint, p256dh, auth });
}

export async function disablePushNotifications() {
    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.getSubscription();
    return subscription.unsubscribe();
}
