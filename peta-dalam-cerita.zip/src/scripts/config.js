const CONFIG = {
  BASE_URL: 'API_BASE_URL',
};

export default CONFIG;
